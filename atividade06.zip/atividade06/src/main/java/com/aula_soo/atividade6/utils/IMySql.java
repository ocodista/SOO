package com.aula_soo.atividade6.utils;

public interface IMySql {
    final String USUARIO = "user";
    final String SENHA = "soo123";
    final String URL = "jdbc:mysql://localhost:3306/db";
    final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
}

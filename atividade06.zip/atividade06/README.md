# SOO

## Docker

Para iniciar as aplicações, rode

```
docker-compose up -d
```

## Testes
Para rodar os testes, rode

```
mvn clean test
```
